/**
 * Portrait-touch adaptation of the OFFICIAL desktop Web GUI (the dsh-LAN
 * approach): while a touch device is in portrait, inject a CSS + gesture
 * layer on top of the running SPA instead of maintaining a second UI. The
 * official layout already auto-collapses the sidebar below 1024px; this
 * layer adds touch-target sizing, 16px inputs (iOS focus zoom), safe-area
 * padding, a floating whale button as the collapsed-sidebar entry (with a
 * verified toggle fallback for cohorts whose layout face mounts inert),
 * swipe gestures, long-press session menus, a bottom-sheet composer picker
 * (model / effort / permission menus), desktop-surface suppression, and
 * composer/header compaction.
 * Landscape, desktop, and wide viewports stay untouched; a manual
 * sessionStorage opt-out (wj-dsh-mobile-force-desktop=1) disables the layer.
 *
 * Selector strategy: CSS Modules class names are hash-prefixed with the
 * semantic name as a stable suffix (`pI_x6G_centerCol`), so attribute
 * suffix selectors survive official rebuilds that only change the hash. The
 * semantic names were read off the 0.1.2-alpha.1 official client build and
 * are re-verified on every GUI QA round; rules borrowed from the dsh-LAN
 * reference (MIT, v47-v78) keep their version comments.
 * @module wj-dsh-remote/client/mobile-adapt
 */

/** Label key the injected surface asks the plugin seat to translate. */
export type AdaptKey = string

/** The window global the plugin apply() wires the layout service into. */
export interface RemoteAdaptGlobal {
  evaluate: () => void
  /** Wired by the plugin apply once ctx.layout is live. */
  toggleSidebar: (() => void) | null
  /** Wired by the plugin apply once ctx.layout is live. */
  closeDetails: (() => void) | null
  /**
   * Wired by the plugin apply once the `remote` locale namespace is bound:
   * the translate seat the injected surface (the whale) reads its label
   * from. Null until then; label reads fall back to English
   * (the SDK's universal fallback) and the 600ms sync tick re-renders the
   * labels once the seat is wired.
   */
  translate: ((key: AdaptKey) => string) | null
  /** Plugin master switch: false reverts the layer, true re-evaluates. */
  setEnabled(on: boolean): void
  /** Replays a pending closeDetails once the layout face is wired (the first apply ran before the wiring). */
  flushCloseDetails(): void
}

/** Storage key for the manual desktop opt-out. */
const FORCE_DESKTOP_KEY = 'wj-dsh-mobile-force-desktop'
/** Storage key for the dragged whale position. */
const WHALE_POS_KEY = 'dsh-remote-whale-pos'
/** Injected stylesheet identity. */
const ADAPT_CSS_ID = 'wj-dsh-remote/mobile-adapt.css'
/** Body class while the adaptation is active. */
const ACTIVE_CLASS = 'dsh-remote-portrait'
/** Body class while the collapsed rail is hidden behind the whale. */
const RAIL_HIDDEN_CLASS = 'dsh-remote-rail-hidden'
/**
 * The official sidebar column root. Also the scope of the row sweep: every row
 * the drag suppression covers is a descendant of it, so the document-wide scan
 * it replaces only ever returned these.
 */
const SIDEBAR_SELECTOR = '[class*="_sidebarCol"]'
/** The official draggable session/project rows (see disableRowDrag). */
const ROW_SELECTOR = '[class*="_sessionRow"], [class*="_projectRow"]'
/** The injected stylesheet, addressed through the same cached lookup. */
const STYLE_SELECTOR = `style[data-plugin-css="${ADAPT_CSS_ID}"]`

/** Whale button id. */
const WHALE_ID = 'dshRemoteWhale'
/** Body class while the header actions are seated in the tabs row. */
const HEADER_SEATED_CLASS = 'dsh-remote-header-seated'
/**
 * Width the seated header actions paint over the tabs row, as a CSS variable
 * on <html>. The row caps its own width with it (see the v80 rules) instead of
 * reserving the space with padding.
 */
const HEADER_RESERVE_VAR = '--dsh-remote-header-actions-reserve'
/**
 * The official application frame. The layout column classes are the anchor:
 * `_frame` is shared by unrelated official components (the chat turn rail,
 * message-image thumbnails, the subagent pill, PlanReviewPanel), so a bare
 * suffix match would restyle and hit-block those. `data-dsh-frame` is the
 * aggregate compat stamp, kept as the fast path.
 */
const APP_FRAME_SELECTOR = '[data-dsh-frame], [class*="_frame"]:has([class*="_centerCol"])'

/**
 * The official composer surface. `_composerSeat` is the plugin's historical
 * anchor; the official `data-dsh-surface="composer"` part attribute is the
 * stable alternative if the class ever gains a modifier.
 */
const COMPOSER_SELECTOR = '[class$="_composerSeat"], [data-dsh-surface="composer"]'

/** Resolve the official application frame (never a nested `_frame` surface). */
function appFrame(): HTMLElement | null {
  const frame = document.querySelector(APP_FRAME_SELECTOR)
  return frame instanceof HTMLElement ? frame : null
}

/**
 * Whether the current viewport is a portrait touch device small enough to
 * need the adaptation.
 */
function isMobilePortrait(): boolean {
  if (typeof window === 'undefined') return false
  if (typeof window.matchMedia !== 'function') return false
  if (!window.matchMedia('(orientation: portrait)').matches) return false
  if (!window.matchMedia('(pointer: coarse)').matches) return false
  if (window.innerWidth >= 1100) return false
  if (window.sessionStorage.getItem(FORCE_DESKTOP_KEY) === '1') return false
  return true
}

/**
 * The injected rules. Grouped by surface; version comments trace rules back
 * to the dsh-LAN reference they were ported from.
 */
const ADAPT_CSS: readonly string[] = [
  'html,body{height:100%}',
  // The app frame fills the dynamic viewport (browser chrome collapse).
  // Scoped to the application frame: a bare [class$="_frame"] also matches the
  // chat turn rail, message thumbnails, the subagent pill and PlanReviewPanel,
  // stretching each to a full-width 100dvh pointer-events:auto block.
  '[class*="_frame"]:has([class*="_centerCol"]){width:100%;height:100dvh}',
  // Collapsed rail: bigger touch targets.
  '[class$="_railFish"] button,[class$="_panelIcon"],[class$="_newSession"]{min-width:44px;min-height:44px}',
  // Message list padding on narrow screens.
  '[class$="_scroll"]{padding:8px 10px}',
  // 16px inputs prevent iOS focus zoom; keep the send button touchy.
  '[class$="_input"],textarea,input{font-size:16px}',
  '[class$="_composer"]{padding-bottom:calc(4px + env(safe-area-inset-bottom))}',
  // v50: slightly smaller type on portrait phones.
  '[class$="_scrollBody"] [class$="_root"]{font-size:14.5px}',
  '[class$="_scrollBody"] [class$="_bubble"]{font-size:14.5px}',
  '[class$="_titleRow"] *{font-size:13px}',
  '[class*="_sidebarCol"] [class$="_root"],[class*="_sidebarCol"] [class$="_newSession"],[class*="_sidebarCol"] [class$="_trigger"],[class*="_sidebarCol"] [class$="_title"]{font-size:13px}',
  '[class*="_sidebarCol"] [class$="_meta"],[class*="_sidebarCol"] [class$="_time"]{font-size:11.5px}',
  // v50: collapsed rail hidden; the whale button is the entry. The frame's
  // grid is inline-styled (56px rail track when collapsed); pin the first
  // track to 0 so content uses the full width. On portrait phones the
  // details track is always 0 (computeColumns drops it when there is no
  // room), so the three-track override is safe here.
  '[class$="_frame"][data-sidebar-collapsed]{grid-template-columns:0 minmax(0,1fr) 0 !important}',
  // The official collapsed sidebar is an absolutely-positioned overlay rail
  // (it leaves the grid flow), so the in-flow centerCol would auto-place
  // into the now-0px FIRST track and collapse the conversation to zero width
  // on an intermittent basis (the rail flips relative <-> absolute as the
  // host overlay mounts). Pin every column to an explicit track so the
  // center always lands on the 1fr track regardless of the sidebar's
  // computed position.
  '[class$="_frame"][data-sidebar-collapsed] [class*="_sidebarCol"]{grid-column:1/2}',
  '[class$="_frame"][data-sidebar-collapsed] [class$="_centerCol"]{grid-column:2/3}',
  '[class$="_frame"][data-sidebar-collapsed] [class$="_detailsCol"]{grid-column:3/4}',
  // Keep the chat header title clear of the floating whale.
  `body.${RAIL_HIDDEN_CLASS} [class$="_titleRow"]{padding-left:52px}`,
  // The whale button itself.
  `#${WHALE_ID}{position:fixed;top:calc(4px + env(safe-area-inset-top));left:calc(8px + env(safe-area-inset-left));z-index:2147482999;width:34px;height:34px;min-width:34px;padding:0;border-radius:10px;background:var(--dsw-alias-bg-module-platform);border:1px solid var(--dsw-alias-border-l2);color:var(--dsw-alias-label-primary);display:flex;align-items:center;justify-content:center;cursor:pointer;box-shadow:0 1px 6px rgba(0,0,0,.25)}`,
  `#${WHALE_ID} svg{width:20px;height:15px;display:block}`,
  `#${WHALE_ID}:active{opacity:.72}`,
  `#${WHALE_ID}{touch-action:none}`,
  // v51/v52: smaller collapse toggle in the expanded sidebar (the toggle
  // carries two classes, so match by containment); v47's panelIcon touch
  // rule forces a 44px min on the icon itself — zero it out so the 13px
  // glyph fits the 18px button.
  '[class*="_sidebarCol"] [class$="_logoRow"] [class*="_iconButton"]{width:18px;height:18px}',
  '[class*="_sidebarCol"] [class$="_logoRow"] [class*="_iconButton"] svg{width:13px;height:13px;min-width:0;min-height:0}',
  // v77: workspace rows' right-side actions (menu + new session) are
  // hover-only on desktop; always show them on mobile touch.
  '[class*="_sidebarCol"] [class*="_projectRow"] [class*="_rowActions"]{display:inline-flex}',
  // v78: mobile long-press on a row must not start native drag.
  '[class*="_sidebarCol"] [class*="_sessionRow"],[class*="_sidebarCol"] [class*="_projectRow"]{-webkit-user-drag:none;user-select:none}',
  // Hide the header Session-log download button (no space on phones).
  '[class$="_headerUtilities"]{display:none}',
  // v52 composer: the two lines (permission / model) stay stacked with zero
  // row gap; the command, context-meter and send/stop buttons float at the
  // left/right edges vertically centered over both lines. "Both lines" is what
  // makes _row the containing block for those three floats: _row is the one box
  // that wraps the lines, so nothing between a float and _row may claim it.
  '[class$="_composerSeat"] [class$="_card"]{margin-bottom:1px}',
  '[class$="_composerSeat"] [class$="_row"]{flex-wrap:wrap;row-gap:0;padding:2px 8px 1px;position:relative}',
  // The attach button is the only file-picker entry on the portrait composer,
  // and taking it out of flow costs it the paint order it had inline: a
  // positioned sibling painted after it (the trailing line, see below) covers
  // it and eats the taps on the covered half. Its own z-index makes the hit
  // layer a property of the button instead of a side effect of a sibling
  // (#1829). It clears the composer's own stacking ladder and stays far below
  // the bottom-sheet menus (2147482000), which own the overlay above it.
  '[class$="_composerSeat"] [class$="_add"]{position:absolute;left:8px;top:50%;transform:translateY(-50%);z-index:10}',
  '[class$="_composerSeat"] [class$="_modes"]{min-width:0;padding-left:38px}',
  // Model line left-aligned with the permission line (same command-button
  // clearance), rows stay tightly stacked.
  // The trailing line is forced onto its own row at flex-basis:100% and carries
  // 116px of side padding (38 left for the command button, 78 right for the
  // send button). Under the default content-box that padding is ADDED to the
  // 100% basis, so the line's own box overflowed the card by exactly 116px and
  // dragged the absolutely-positioned send button out with it: on a 393px phone
  // the card ended at x=367 while the button sat at x=433..467, past the
  // viewport's right edge, which is the unreachable button the reporter
  // measured (#1818). border-box contains the padding inside the basis, so the
  // line stays within the card and the button lands back inside it.
  //
  // The line stays UNPOSITIONED on purpose. position:relative arrived here with
  // the compact picker and outlived it, but this box is the LAST line only: as
  // the nearest positioned ancestor it took the containing block from _row, so
  // the send button and the context meter centered inside the trailing line
  // instead of over both lines - the send button rode the input's bottom edge,
  // out of line with the attach button - and, painted after the out-of-flow
  // attach button, the line covered that button's lower half and swallowed the
  // taps there (#1829).
  '[class$="_composerSeat"] [class$="_trailing"]{box-sizing:border-box;flex-basis:100%;min-height:32px;justify-content:flex-start;padding-left:38px;padding-right:78px}',
  '[class$="_composerSeat"] [class$="_trailing"] *{font-size:12px}',
  // v54: smaller permission/model buttons (font + height). v79: the
  // permission trigger collapses to its shield icon on phones — the label
  // text is the first thing a narrow row drops (the icon color carries the
  // state), matching the dsh-LAN compact composer.
  '[class$="_composerSeat"] [class$="_modes"] [class$="_trigger"]{height:24px;min-height:24px;font-size:12px}',
  '[class$="_composerSeat"] [class$="_trailing"] [class$="_trigger"]{height:24px;min-height:24px;font-size:11px}',
  // Context meter + send/stop float at the right edge, vertically centered
  // over both lines (the meter's root contains the track).
  '[class$="_composerSeat"] [class$="_trailing"] > [class$="_root"]:has([class$="_track"]){position:absolute;right:52px;top:50%;transform:translateY(-50%)}',
  '[class$="_composerSeat"] [class$="_primary"]{position:absolute;right:8px;top:50%;transform:translateY(-50%)}',
  // v79: the model picker menu anchors right:0 to its narrow trigger, so on
  // a phone both the picker menu and the model list fly past the left
  // viewport edge (model names unreadably cut). Turn the picker into a
  // bottom sheet: the composer seat carries an identity transform, which
  // would still become the containing block for fixed children, so free it
  // first; then pin every seat menu to the viewport bottom with real touch
  // targets. Covers the picker, the model list, and the other composer
  // popovers (permission presets, attachments) alike.
  '[class$="_composerSeat"]{transform:none !important}',
  '[class$="_composerSeat"] [class$="_menu"]{position:fixed !important;left:8px !important;right:8px !important;top:auto !important;bottom:calc(8px + env(safe-area-inset-bottom)) !important;width:auto !important;max-width:none !important;max-height:70dvh !important;overflow-y:auto !important;z-index:2147482000}',
  '[class$="_composerSeat"] [class$="_menu"] [class$="_cell"]{height:44px;min-height:44px;font-size:13px}',
  // v79's compact picker (two synthesized model/effort icon buttons in the
  // tools row, the trailing text trigger hidden behind a body class, and the
  // trailing line collapsed to zero width) was removed at the user's request.
  // The portrait composer keeps the official text trigger with the trailing
  // line rules above; the bottom-sheet rules immediately above still apply to
  // the official menu.
  // Bottom stats line (N rounds / M steps) two sizes below the tabs; v55
  // wraps freely but clamps at two lines (the official rule is nowrap +
  // single-line ellipsis); v60 drops the official 32px right padding.
  '[class$="_composerSeat"] [data-slot="conversation.composer.dock"] [class$="_root"]{font-size:10px;white-space:normal;word-break:break-word;overflow-wrap:anywhere;display:-webkit-box;-webkit-line-clamp:2;-webkit-box-orient:vertical;overflow:hidden;text-align:left;line-height:13px;letter-spacing:-0.2px;padding-left:0;padding-right:0}',
  // (user bubbles keep the v50 14.5px via the _bubble rule.)
  '[class$="_scrollBody"] [class$="_root"]{font-size:13px}',
  // v58/v65 port note: the dsh-LAN `_body` gap:6px compaction is deliberately
  // NOT ported. The official message row is a shrinkable flex column whose
  // bottom-anchored body then measures shorter than its text (13px root font
  // on a fixed 24px line box), and the extra gap pushed the first text line
  // above the row box — every assistant message clipped its top half on the
  // phone (verified on the real GUI; the removal restores natural heights).
  // v58/v65: on touch, taps leave :hover/:focus stuck, so official Tooltip
  // bubbles stay visible on mobile. The bubble class hash sits AFTER the
  // name, so match by containment, still scoped by role=tooltip so user
  // message bubbles (no tooltip role) stay visible.
  '[class*="_bubble"][role="tooltip"]{display:none}',
  // v65: PlanReviewPanel shares the _frame/_card suffixes and overflows a
  // narrow phone; pin it to the viewport with border-box and cap its height
  // so the card sits fully on screen.
  '[class$="_composerSeat"] [class$="_frame"]{box-sizing:border-box;width:100%;max-width:100%;padding-left:12px;padding-right:12px;height:auto;max-height:calc(100dvh - 96px);align-items:flex-start;overflow-y:auto}',
  '[class$="_composerSeat"] [class$="_frame"] [class$="_card"]{max-width:none;width:100%}',
  // v67: header actions (agent-preset mode label + background-task badge)
  // are re-seated from the title row into the tabs row; hidden in the
  // original spot so React re-renders do not flicker them back.
  // Only while the layer has taken the actions over: out of flow (so the
  // title row keeps its own layout and React keeps owning the node) and
  // painted over the tabs row by the transform alignActionsText computes.
  `body.${HEADER_SEATED_CLASS} [class$="_header"] [class$="_titleCluster"] [class$="_headerActions"]{position:absolute;left:0;top:0;margin:0;display:flex;align-items:center;gap:6px;flex:none;z-index:2}`,
  // v70: match the tab text size with the seated mode label (12px); NB
  // [class$="_tab"] misses the active tab (its class ends in "_tabActive")
  // — containment so BOTH tabs match.
  '[class$="_header"] [class$="_tabs"] [class*="_tab"]{font-size:12px;white-space:nowrap}',
  // v80: the tabs row must give the painted actions their width up on its own.
  // The v67 padding reservation could not do it: the row is a nowrap flex
  // container, and once the tab labels plus their gaps overflow the reduced
  // content box the flex items spill over the padding box, so the trailing
  // tabs render underneath the actions (reported on a phone: a long agent
  // preset label covered the last tabs). Cap the row against the reserve and
  // let the labels scroll instead. The value rides a CSS variable on <html>
  // because the update lands before React re-creates the row node, and an
  // inline reservation on that node is dropped until the next sync tick.
  // The 2px bottom padding keeps the active-tab underline inside the clipping
  // box; the matching negative margin keeps the header height official.
  `body.${HEADER_SEATED_CLASS} [class$="_header"] [class$="_tabs"]{max-width:max(0px,calc(100% - var(${HEADER_RESERVE_VAR},0px)));overflow-x:auto;overflow-y:hidden;scrollbar-width:none;-webkit-overflow-scrolling:touch;padding-bottom:2px;margin-bottom:-2px}`,
  `body.${HEADER_SEATED_CLASS} [class$="_header"] [class$="_tabs"]::-webkit-scrollbar{display:none}`,
  `body.${HEADER_SEATED_CLASS} [class$="_header"] [class$="_tabs"] > [class*="_tab"]{flex:0 0 auto}`,
  // Mobile scope: hide the plugin surfaces that do not fit a phone — the
  // right-hand details column and every desktop-oriented tool surface. The
  // list keys on the L2 semantic roots (data-dsh-plugin, ownership stays
  // with the declaring plugin), so official class churn cannot resurrect
  // them. These are render suppressions: the client bundles still load.
  // The pet is part of the hidden set by design: the mobile remote mirror
  // carries the desktop-less phone surface, and a floating pet would only
  // cover the small viewport. The suppression is the requirement, not a bug.
  `body.${ACTIVE_CLASS} [class$=\"_detailsCol\"]{display:none !important}`,
  `body.${ACTIVE_CLASS} [data-dsh-plugin=\"ssh\"],`,
  `body.${ACTIVE_CLASS} [data-dsh-plugin=\"skill-explorer\"],`,
  `body.${ACTIVE_CLASS} [data-dsh-plugin=\"task-board\"],`,
  `body.${ACTIVE_CLASS} [data-dsh-plugin=\"git-graph\"],`,
  `body.${ACTIVE_CLASS} [data-dsh-plugin=\"pet\"],`,
  `body.${ACTIVE_CLASS} [data-dsh-plugin=\"usage\"]{display:none !important}`,
  // The official workbench (Files / source control) mounts into a
  // full-viewport portal layer with no data-dsh-plugin root, so the plugin
  // list above cannot key on it; its open state persists across page loads,
  // and on a phone it covers the entire conversation with no visible close
  // control — the remote-opens-to-an-empty-screen report. Hide the
  // workbench panel only: the same portal layer also hosts the settings
  // modal, which must stay reachable (verified in the GUI QA round).
  `body.${ACTIVE_CLASS} [class$=\"_overlayLayer\"] [class$=\"_workbench\"]{display:none !important}`,
  // v68: settings modal on mobile — the official panel is a fixed 800px
  // two-column layout (nav + content); switch to a column layout: the
  // section nav becomes a horizontal scrollable row on top.
  // Scoped to the portrait body class like the suppressions above: these
  // are the only rules in this array that reshape an official two-column
  // surface, and the overlay portal is shared with every other dialog.
  // Unscoped, the tag — which lives in <head> for as long as the layer
  // is active and is restored by the sync tick after a revert —
  // collapsed the DESKTOP settings panel into a stacked column (measured
  // on a real 1440px host: panel flex-direction row -> column, nav 800px
  // tall -> 236px, content 612px -> 800px wide and pushed below the nav).
  `body.${ACTIVE_CLASS} [class$="_overlay"] [class$="_panel"]{flex-direction:column;max-height:calc(100dvh - 32px)}`,
  `body.${ACTIVE_CLASS} [class$="_overlay"] [class$="_panel"] [class$="_nav"]{flex-direction:row;gap:4px;width:100%;padding:12px 12px 0;overflow-x:auto;overflow-y:hidden}`,
  `body.${ACTIVE_CLASS} [class$="_overlay"] [class$="_panel"] [class$="_navTitle"]{display:none}`,
  `body.${ACTIVE_CLASS} [class$="_overlay"] [class$="_panel"] [class$="_navList"]{flex-direction:row;gap:4px}`,
  `body.${ACTIVE_CLASS} [class$="_overlay"] [class$="_panel"] [class$="_navCell"]{height:34px;padding:0 12px;gap:6px;flex:none;border-radius:10px}`,
  `body.${ACTIVE_CLASS} [class$="_overlay"] [class$="_panel"] [class$="_navLabel"]{font-size:13px}`,
  `body.${ACTIVE_CLASS} [class$="_overlay"] [class$="_panel"] [class$="_content"]{flex:1;min-height:0}`,
]

/** The DeepSeek fish glyph (the official brand mark path). */
const FISH_PATH = 'M22.9168 1.43018C22.6713 1.31018 22.5658 1.53918 22.4223 1.65519C22.3733 1.69269 22.3318 1.74169 22.2903 1.78669C21.9317 2.1697 21.5127 2.42121 20.9657 2.39121C20.1657 2.34621 19.4827 2.59771 18.8787 3.20973C18.7502 2.45521 18.3236 2.0047 17.6746 1.71569C17.3351 1.56568 16.9916 1.41518 16.7536 1.08867C16.5876 0.856163 16.5421 0.597155 16.4591 0.341647C16.4061 0.187643 16.3536 0.0301382 16.1761 0.00363739C15.9836 -0.0263635 15.9081 0.135141 15.8326 0.270145C15.5306 0.822162 15.4136 1.43018 15.4251 2.0462C15.4516 3.43174 16.0366 4.53527 17.1991 5.3203C17.3311 5.4103 17.3651 5.5003 17.3236 5.63181C17.2441 5.90231 17.1501 6.16482 17.0671 6.43533C17.0141 6.60784 16.9351 6.64584 16.7501 6.57033C16.1121 6.30383 15.5611 5.90931 15.074 5.4328C14.2475 4.63328 13.5 3.75075 12.568 3.05973C12.349 2.89822 12.13 2.74822 11.9034 2.60522C10.9524 1.68169 12.028 0.923165 12.277 0.833162C12.5375 0.739159 12.3675 0.41615 11.5259 0.42015C10.6844 0.42365 9.91439 0.705658 8.93286 1.08117C8.78935 1.13767 8.63835 1.17867 8.48384 1.21267C7.59332 1.04367 6.66829 1.00617 5.70226 1.11517C3.88321 1.31768 2.43016 2.1777 1.36213 3.64575C0.0790928 5.4103 -0.222916 7.41536 0.146595 9.50642C0.535106 11.7105 1.66014 13.535 3.38869 14.9616C5.18125 16.4406 7.24581 17.1657 9.60138 17.0266C11.0319 16.9441 12.6245 16.7526 14.421 15.2321C14.874 15.4576 15.3496 15.5476 16.1381 15.6151C16.7456 15.6716 17.3306 15.5851 17.7836 15.4911C18.4931 15.3411 18.4441 14.6841 18.1876 14.5636C16.1081 13.595 16.5646 13.9891 16.1496 13.67C17.2061 12.42 18.8202 10.1979 19.3182 7.17235C19.3672 6.83834 19.4297 6.36783 19.4222 6.09732C19.4182 5.93231 19.4562 5.86831 19.6447 5.84931C20.1657 5.78931 20.6712 5.64681 21.1357 5.3913C22.4833 4.65528 23.0268 3.44624 23.1548 1.9972C23.1738 1.77569 23.1508 1.54668 22.9168 1.43018Z'

/**
 * Install the adaptation layer. Runs once per page (idempotent); the
 * evaluate loop re-applies on orientation/resize and reverts off-portrait.
 */
export function startMobileAdapt(): void {
  if (typeof window === 'undefined' || typeof document === 'undefined') return
  if ((window as unknown as { __dshRemoteAdaptInstalled?: boolean }).__dshRemoteAdaptInstalled === true) return
  ;(window as unknown as { __dshRemoteAdaptInstalled?: boolean }).__dshRemoteAdaptInstalled = true

  const w = window as unknown as { __dshRemoteAdapt?: RemoteAdaptGlobal } & Record<string, unknown>
  /**
   * Label lookup for the injected surfaces: the `remote` namespace seat wired
   * by the plugin apply, else the English fallback (the SDK's universal
   * fallback; the sync tick re-renders the labels once the seat is live).
   */
  const surfaceText = (key: AdaptKey, fallback: string): string => {
    try {
      const out = w.__dshRemoteAdapt?.translate?.(key)
      return typeof out === 'string' && out.length > 0 ? out : fallback
    } catch {
      return fallback
    }
  }
  let active = false
  let savedViewportContent: string | null = null
  let whaleEl: HTMLButtonElement | null = null
  let whaleObserver: MutationObserver | null = null
  /** Header subtree observer: marks the geometry measurement dirty on re-render. */
  let headerObserver: MutationObserver | null = null
  /** Document child-list observer: invalidates the cached-absent selector set. */
  let domObserver: MutationObserver | null = null
  let observedHeader: Element | null = null
  /** Whether the seated-actions geometry needs re-measuring (see alignActionsText). */
  let headerGeometryDirty = true
  let whaleTimer: number | null = null
  let whaleSuppressClick = false
  let whaleShown = false
  let drag: { x: number; y: number; left: number; top: number; moved: boolean } | null = null
  let swipeTouch: { x: number; y: number; id: number; el: Element | null } | null = null
  let lastComposerTap = 0
  // Plugin master switch: the module-scope layer installs before any config
  // is readable, so the plugin apply() flips this through setEnabled() once
  // the settings snapshot settles (disabled plugin = no injected surface).
  let adaptEnabled = true

  /**
   * Idempotently (re-)install the adaptation stylesheet. The rules live in
   * one <style> tag keyed by data-plugin-css; the sync tick re-runs this so
   * a tag lost to any external DOM cleanup is restored within one tick
   * instead of silently dropping the suppressions (portrait pet hiding,
   * rail compaction) while the body class stays.
   */
  function ensureAdaptStyle(): void {
    if (nodeOf(STYLE_SELECTOR) !== null) return
    const tag = document.createElement('style')
    tag.dataset.plugin = 'wj-dsh-remote'
    tag.dataset.pluginCss = ADAPT_CSS_ID
    tag.textContent = ADAPT_CSS.join('')
    document.head.appendChild(tag)
    // Seed the lookup cache: the tag is created here, outside nodeOf, so the
    // negative cache could otherwise report it missing for one more tick and
    // stack a duplicate stylesheet.
    nodeCache.set(STYLE_SELECTOR, tag)
    nodeMissCache.delete(STYLE_SELECTOR)
  }

  function apply(): void {
    if (active) return
    active = true
    // First statement of the activation, before any lookup: nothing observed the
    // document while the layer was reverted (the observer is created below), so
    // no "absent" verdict recorded earlier may be served now. Clearing here
    // rather than beside the observer also covers the lookups this path runs
    // before that point.
    forgetAbsentSelectors()
    document.body.classList.add(ACTIVE_CLASS)
    // A details panel opened before the viewport rotated into portrait (or
    // restored across reloads) would sit behind the display:none above;
    // closing it through the official face unmounts the surface entirely.
    // The layout face throws by design when the root entry has not mounted
    // yet (boot-order), which is a tolerated no-op here — the plugin apply
    // replays it through flushCloseDetails once the wiring is live.
    try {
      w.__dshRemoteAdapt?.closeDetails?.()
    } catch {}
    ensureAdaptStyle()
    // viewport-fit=cover enables env(safe-area-inset-*); restore on revert.
    const meta = document.querySelector('meta[name=viewport]')
    if (meta instanceof HTMLMetaElement && meta.getAttribute('content') !== null && !(meta.getAttribute('content') ?? '').includes('viewport-fit')) {
      savedViewportContent = meta.getAttribute('content')
      meta.setAttribute('content', `${savedViewportContent}, viewport-fit=cover`)
    }
    ensureWhale()
    ensureDomObserver()
    syncWhale()
    // React builds nodes with attributes before inserting them, so
    // attribute observers miss the initial collapsed state — a light
    // interval is the reliable sync.
    setWhaleTimer(true)
    seatHeaderActions()
  }

  function revert(): void {
    if (!active) return
    active = false
    unseatHeaderActions()
    restoreRowDrag()
    document.body.classList.remove(ACTIVE_CLASS)
    document.body.classList.remove(RAIL_HIDDEN_CLASS)
    const tag = document.querySelector(`style[data-plugin-css="${ADAPT_CSS_ID}"]`)
    tag?.remove()
    const meta = document.querySelector('meta[name=viewport]')
    if (meta instanceof HTMLMetaElement && savedViewportContent !== null) {
      meta.setAttribute('content', savedViewportContent)
      savedViewportContent = null
    }
    if (whaleEl !== null) whaleEl.style.display = 'none'
    // The next apply() is a hidden-to-shown transition again: without this the
    // whale would keep its pre-revert position state and skip the clamp.
    whaleShown = false
    setWhaleTimer(false)
    if (whaleObserver !== null) {
      whaleObserver.disconnect()
      whaleObserver = null
    }
    if (domObserver !== null) {
      domObserver.disconnect()
      domObserver = null
    }
    // Nothing observes the document from here on; a verdict recorded now could
    // not be trusted after the next apply().
    forgetAbsentSelectors()
  }

  /**
   * Observe the document for the two kinds of change that can make a cached-absent
   * target discoverable again (see nodeOf): node insertion/removal, and the
   * class / compat-stamp attributes the cached selectors match on.
   *
   * Body class writes are excluded by target: the layer toggles three body
   * classes every tick, and counting those would invalidate the negative cache
   * on every tick and restore the very scan this cache removes. They cannot
   * create a target either — every cached selector matches an element other
   * than <body>.
   *
   * The record queue is drained on a microtask, so this stays off the layout
   * path; a chat turn's insertions are a handful per second, not per element.
   */
  function ensureDomObserver(): void {
    if (domObserver !== null || typeof MutationObserver === 'undefined' || !document.body) return
    domObserver = new MutationObserver((records) => {
      for (const record of records) {
        if (record.type === 'childList' || record.target !== document.body) {
          noteDomChange()
          return
        }
      }
    })
    domObserver.observe(document.body, {
      childList: true,
      subtree: true,
      attributes: true,
      attributeFilter: ['class', 'data-dsh-frame'],
    })
  }

  /** Start/stop the 600ms sync tick; a no-op when already in the asked state. */
  function setWhaleTimer(on: boolean): void {
    if (on && whaleTimer === null && active) {
      whaleTimer = window.setInterval(syncWhale, 600)
    } else if (!on && whaleTimer !== null) {
      window.clearInterval(whaleTimer)
      whaleTimer = null
    }
  }

  /**
   * The official sidebar toggle in the logo row. The row's own `_toggle` class
   * is the precise anchor; the row's last button is the fallback for cohorts
   * that only expose the generic icon-button class (the first button is the
   * brand, which navigates home — never click that one). `_railFish` is kept
   * for older compositions that carried a rail fish button.
   */
  function officialSidebarToggle(): HTMLElement | null {
    const rail = document.querySelector('[class$="_railFish"] button')
    if (rail instanceof HTMLElement) return rail
    const row = document.querySelector('[class$="_logoRow"]')
    if (row === null) return null
    const toggles = row.querySelectorAll('button[class*="_toggle"]')
    const last = toggles.length > 0 ? toggles[toggles.length - 1] : row.querySelectorAll('button')[row.querySelectorAll('button').length - 1]
    return last instanceof HTMLElement ? last : null
  }
  /**
   * Toggle the sidebar through the official rail/logo toggle first, then
   * verify the flip and fall back to the wired layout face.
   *
   * The order is evidence-driven: the official toggle owns its own store
   * actions and flips the state on every cohort we support, while the wired
   * LayoutController is mounted yet inert on the installed cohort — calling it
   * left `data-sidebar-collapsed` untouched for the whole 800ms observation
   * window, so face-first made every whale tap wait out the verification
   * delay before anything moved. The face stays the fallback for compositions
   * that render no logo-row toggle, and it is only called after the toggle
   * demonstrably failed, so the two can never cancel each other out.
   */
  function toggleSidebarVerified(): void {
    const frame = appFrame()
    const collapsedBefore = frame !== null ? frame.hasAttribute('data-sidebar-collapsed') : null
    const face = w.__dshRemoteAdapt?.toggleSidebar
    const callFace = (): void => {
      if (typeof face !== 'function') return
      try { face() } catch {}
    }
    const toggle = officialSidebarToggle()
    if (collapsedBefore === null || toggle === null) {
      // No frame to verify against, or no official toggle: the face is the
      // only available control.
      if (toggle !== null) toggle.click()
      else callFace()
      return
    }
    toggle.click()
    let tries = 0
    const verify = (): void => {
      if (!active) return
      const frameNow = appFrame()
      if (frameNow === null) return
      if (frameNow.hasAttribute('data-sidebar-collapsed') !== collapsedBefore) return
      tries += 1
      if (tries < 2) {
        window.setTimeout(verify, 120)
        return
      }
      callFace()
    }
    window.setTimeout(verify, 120)
  }
  function ensureWhale(): void {
    if (whaleEl !== null || !document.body) return
    const whale = document.createElement('button')
    whale.id = WHALE_ID
    whale.type = 'button'
    whale.dataset.dshPlugin = 'wj-dsh-remote'
    // The label reads the `remote` namespace (wired by the plugin apply);
    // before wiring it falls back to English and the sync tick re-renders it.
    const whaleLabel = surfaceText('mobile.whale.open', 'Open sidebar')
    whale.title = whaleLabel
    whale.setAttribute('aria-label', whaleLabel)
    whale.innerHTML = `<svg viewBox="0 0 23.16 17.04" fill="none" aria-hidden="true"><path d="${FISH_PATH}" fill="currentColor"/></svg>`
    whale.addEventListener('click', () => {
      if (whaleSuppressClick) {
        whaleSuppressClick = false
        return
      }
      toggleSidebarVerified()
    })
    // v51: the whale floats — pointer-drag repositions it (persisted).
    whale.addEventListener('pointerdown', (e) => {
      if (whaleEl === null) return
      if (e.button !== 0 && e.pointerType === 'mouse') return
      // v61: opening the sidebar must not leave a focused composer input
      // behind — on phones a still-focused input makes the first tap re-pop
      // the keyboard (iOS) or keeps it open. Blur at pointerdown (before the
      // tap completes; click is too late for iOS) and block pending
      // programmatic refocus.
      if (active && isComposerField(document.activeElement)) {
        // The composer field is a contenteditable div (the official client
        // renders no textarea), so the old textarea/input lookup never matched
        // it while a bare `input` branch could blur an unrelated field.
        document.activeElement.blur()
        lastComposerTap = 0
      }
      drag = { x: e.clientX, y: e.clientY, left: whale.offsetLeft, top: whale.offsetTop, moved: false }
      try { whale.setPointerCapture(e.pointerId) } catch {}
      e.preventDefault()
      e.stopPropagation()
    })
    whale.addEventListener('pointermove', (e) => {
      if (whaleEl === null || drag === null) return
      const dx = e.clientX - drag.x
      const dy = e.clientY - drag.y
      drag.moved = drag.moved || Math.abs(dx) > 3 || Math.abs(dy) > 3
      whaleEl.style.left = `${Math.min(Math.max(4, drag.left + dx), window.innerWidth - 38)}px`
      whaleEl.style.top = `${Math.min(Math.max(4, drag.top + dy), window.innerHeight - 38)}px`
      e.preventDefault()
      e.stopPropagation()
    })
    const endWhaleDrag = (): void => {
      if (whaleEl === null || drag === null) return
      const moved = drag.moved
      drag = null
      whaleSuppressClick = moved
      try {
        window.localStorage.setItem(WHALE_POS_KEY, JSON.stringify({ x: whaleEl.offsetLeft, y: whaleEl.offsetTop }))
      } catch {}
    }
    whale.addEventListener('pointerup', endWhaleDrag)
    // A cancelled pointer (system gesture, incoming call) is not a drag end:
    // keep the click un-suppressed so the next real tap still toggles.
    whale.addEventListener('pointercancel', () => {
      drag = null
      whaleSuppressClick = false
    })
    whaleEl = whale
    document.body.appendChild(whale)
  }

  /**
   * Write one row's recorded official draggable state back onto it.
   * @param row - the tracked row element.
   * @param original - the recorded attribute value, or null when it was absent.
   */
  function restoreRowDragState(row: Element, original: string | null): void {
    if (original === null) row.removeAttribute('draggable')
    else row.setAttribute('draggable', original)
  }

  /**
   * Restore the official draggable state this layer overrode while active.
   * Rows are React-owned and may have been re-created meanwhile, so only the
   * tracked elements are touched; a detached element is written back too
   * (harmless, and it keeps the entry prunable at every tick).
   */
  function restoreRowDrag(): void {
    if (dragOverridden.size === 0) return
    for (const [row, original] of dragOverridden) restoreRowDragState(row, original)
    dragOverridden.clear()
  }

  /** Restore a dragged position when the whale becomes visible again. */
  function applyWhalePos(): void {
    if (whaleEl === null) return
    let pos: { x?: unknown; y?: unknown } | null = null
    try {
      pos = JSON.parse(window.localStorage.getItem(WHALE_POS_KEY) ?? 'null') as { x?: unknown; y?: unknown } | null
    } catch {}
    if (pos !== null && typeof pos.x === 'number' && typeof pos.y === 'number') {
      // Clamp to the current viewport: a position saved on a larger screen
      // (resize, split-screen, rotation) must not park the whale — the only
      // portrait sidebar entry — out of reach.
      const x = Math.min(Math.max(4, pos.x), window.innerWidth - 38)
      const y = Math.min(Math.max(4, pos.y), window.innerHeight - 38)
      whaleEl.style.left = `${x}px`
      whaleEl.style.top = `${y}px`
    }
  }

  // v78: on touch, official session/project rows are draggable for
  // reordering; a long-press would start native drag instead of our action
  // menu. Force them non-draggable while the adapt is active (React may
  // re-create rows, so re-apply on the sync tick).
  /** Rows whose official draggable state this layer overrode (restored on revert). */
  const dragOverridden = new Map<Element, string | null>()
  function disableRowDrag(): void {
    if (!active) return
    const rows = sidebarRows()
    for (const row of rows) {
      if (row.getAttribute('draggable') !== 'false') {
        if (!dragOverridden.has(row)) dragOverridden.set(row, row.getAttribute('draggable'))
        row.setAttribute('draggable', 'false')
      }
    }
    // React replaces rows as the session list re-renders; a detached row can
    // never be restored by a later revert, so keeping it here would retain the
    // whole detached subtree (and its children) for the page lifetime. Its
    // official state goes back on the node itself and the entry is dropped:
    // a node React re-attaches is recorded again on the next tick.
    if (dragOverridden.size === 0) return
    for (const [row, original] of dragOverridden) {
      if (row.isConnected) continue
      restoreRowDragState(row, original)
      dragOverridden.delete(row)
    }
  }

  /**
   * Official nodes resolved through the document and cached while they stay
   * connected. The sync tick runs every 600ms for the page lifetime, and these
   * selectors (suffix class matches, :has()) cannot use Blink's fast paths, so
   * every miss walks the whole mounted DOM — the official chat keeps the whole
   * conversation mounted, i.e. tens of thousands of elements. React replaces a
   * node on a major re-render, which the isConnected guard detects.
   */
  const nodeCache = new Map<string, Element>()
  /**
   * Selectors known to be absent as of {@link domGeneration}. A miss is the
   * common case, not the exception: the layer holds no overlay of its own, and
   * several official surfaces it looks for (tabs row, tools row, sidebar rows)
   * legitimately do not exist at once. Re-walking a conversation-sized document
   * for the same absent selector on every 600ms tick was waste that almost
   * always resolved to null: five document-wide lookups per tick on the measured
   * fixture, zero after this cache. That is a lookup count — the wall-clock
   * saving is real while the mounted content is quiet and shrinks to the
   * row-scope saving when a turn streams (see the Agent Note for the harness and
   * the before/after numbers).
   *
   * A miss is trusted only while the observed content has not changed, so a
   * surface that appears is still found on the very next tick — the same
   * discovery latency the unconditional probe had. The cache is never aged by a
   * clock: it is cleared by {@link noteDomChange} while the observer is live and
   * by {@link forgetAbsentSelectors} across the windows where it is not (apply
   * and revert). One blind spot is deliberate and load-bearing: the observer
   * watches <body>, so a head-resident target is not covered by that signal —
   * the one such target is seeded into the cache where it is created (see
   * ensureAdaptStyle).
   */
  const nodeMissCache = new Set<string>()
  /**
   * Bumped whenever a cached target may have appeared or disappeared. A surface
   * qualifies on a class token or on the aggregate compat stamp
   * (`data-dsh-frame`), so both insertions/removals AND those two attributes
   * can change the answer. Nothing the layer writes per tick lands here: its own
   * class writes are all on <body>, and its row/transform/label writes touch
   * other attributes entirely (see ensureDomObserver).
   */
  let domGeneration = 0
  /** The generation the negative cache was recorded against. */
  let missGeneration = -1

  function noteDomChange(): void {
    domGeneration += 1
  }

  /**
   * Drop every cached "absent" verdict. Called on apply and revert: while the
   * observer is disconnected the layer is blind to insertions, so a verdict
   * recorded before the gap could otherwise outlive the change that falsified
   * it and be served without a probe. The positive cache needs no equivalent —
   * its `isConnected` guard already re-resolves a replaced node.
   */
  function forgetAbsentSelectors(): void {
    nodeMissCache.clear()
    domGeneration += 1
  }

  function nodeOf(selector: string): Element | null {
    const cached = nodeCache.get(selector)
    if (cached !== undefined) {
      // A node React replaced is no longer connected; drop it and fall through
      // so the lookup below can find its replacement.
      if (cached.isConnected) return cached
      nodeCache.delete(selector)
    }
    if (missGeneration !== domGeneration) {
      nodeMissCache.clear()
      missGeneration = domGeneration
    }
    if (nodeMissCache.has(selector)) return null
    const found = document.querySelector(selector)
    if (found === null) {
      nodeMissCache.add(selector)
      return null
    }
    nodeCache.set(selector, found)
    return found
  }

  /**
   * The session/project rows the drag suppression covers, scoped to the cached
   * sidebar root. Each row carries the sidebar column class as an ancestor, so
   * the document-wide scan this replaces only ever returned rows from here.
   */
  function sidebarRows(): Element[] {
    const sidebar = nodeOf(SIDEBAR_SELECTOR)
    if (sidebar === null) return []
    return Array.from(sidebar.querySelectorAll(ROW_SELECTOR))
  }

  /** The official application frame, through the same cached lookup. */
  function frameEl(): HTMLElement | null {
    const frame = nodeOf(APP_FRAME_SELECTOR)
    return frame instanceof HTMLElement ? frame : null
  }

  function syncWhale(): void {
    // Keep the stylesheet present while the layer is active (the tick runs
    // every 600ms; see ensureAdaptStyle for why the tag can need a re-assert).
    if (active) ensureAdaptStyle()
    if (whaleEl === null) return
    if (!active) {
      whaleEl.style.display = 'none'
      return
    }
    const collapsed = frameEl()?.hasAttribute('data-sidebar-collapsed') === true
    const overlayUp = nodeOf('[class$="_overlay"]') !== null
    const show = collapsed && !overlayUp
    // Restore on every hidden-to-shown transition — including the very
    // first show on a fresh page load, where the inline display is still
    // '' and a CSS-read guard would never fire.
    if (show && !whaleShown) applyWhalePos()
    whaleEl.style.display = show ? '' : 'none'
    whaleShown = show
    // Re-read the label every tick so a locale switch is picked up live.
    const whaleLabel = surfaceText('mobile.whale.open', 'Open sidebar')
    if (whaleEl.title !== whaleLabel) whaleEl.title = whaleLabel
    if (whaleEl.getAttribute('aria-label') !== whaleLabel) whaleEl.setAttribute('aria-label', whaleLabel)
    document.body.classList.toggle(RAIL_HIDDEN_CLASS, collapsed)
    disableRowDrag()
    seatHeaderActions()
    alignActionsText()
  }

  // v67: on mobile the header actions (agent-preset mode label + background
  // task badge) move from the title row into the tabs row. React re-creates
  // the node in its original spot on re-render, so the interval re-seats it;
  // stale seated copies are removed first. The original spot is only hidden
  // while a seat actually exists: the tabs row renders only for multi-tab
  // sessions, and hiding the actions without a seat target made them vanish.
  function seatHeaderActions(): void {
    if (!active) return
    const header = nodeOf('[class$="_header"]')
    const tabs = header !== null ? header.querySelector('[class$="_tabs"]') : null
    const actions = header !== null ? header.querySelector('[class$="_titleCluster"] [class$="_headerActions"]') : null
    // The actions node is NOT moved: it is a React-owned host node whose badge
    // button carries live handlers, and re-parenting it makes React's later
    // insertBefore/removeChild anchors point at a node that is no longer a
    // child of the recorded parent (a NotFoundError in the commit phase). The
    // injected CSS takes it out of flow and the transform below paints it over
    // the tabs row instead.
    const seated = header !== null && tabs !== null && actions !== null
    document.body.classList.toggle(HEADER_SEATED_CLASS, seated)
    ensureHeaderObserver(seated ? header : null)
  }

  // Paint the mode/badge over the tabs row: the actions keep their DOM slot in
  // the title cluster (out of flow via CSS) and are moved with a transform, so
  // the tabs row reserves room with padding instead of the node being moved.
  // The tabs row height is not stable (a background task badge grows it) and
  // the official right padding differs per cohort, so both axes are measured
  // and converged each time the header geometry is dirty.
  function alignActionsText(): void {
    if (!active) return
    const header = nodeOf('[class$="_header"]')
    if (header === null) return
    const tabs = header.querySelector('[class$="_tabs"]')
    const actions = header.querySelector('[class$="_titleCluster"] [class$="_headerActions"]')
    if (tabs === null || actions === null || !(tabs instanceof HTMLElement) || !(actions instanceof HTMLElement)) return
    if (!headerGeometryDirty) return
    headerGeometryDirty = false
    const tabBtn = tabs.querySelector(':scope > [class*="_tab"]')
    const textBottom = (el: Element | null): number | null => {
      if (el === null) return null
      const text = Array.from(el.childNodes).find((n) => n.nodeType === 3 && n.textContent !== null && n.textContent.trim() !== '')
      if (text === undefined) return null
      try {
        const range = document.createRange()
        range.selectNode(text)
        return range.getBoundingClientRect().bottom
      } catch {
        return null
      }
    }
    const translate = /translate\((-?[\d.]+)px,\s*(-?[\d.]+)px\)/.exec(actions.style.transform ?? '')
    let dx = translate !== null ? parseFloat(translate[1] ?? '0') : 0
    let dy = translate !== null ? parseFloat(translate[2] ?? '0') : 0
    const actionsRect = actions.getBoundingClientRect()
    // Horizontal: the actions' right edge lands on the header's content edge,
    // NOT on the tabs row's right edge. The row caps its own width against the
    // reserve below (v80), so anchoring to the row would let the pair walk
    // leftwards on every measurement.
    const headerRect = header.getBoundingClientRect()
    const headerStyle = getComputedStyle(header)
    const contentRight = headerRect.right - (parseFloat(headerStyle.paddingRight) || 0) - (parseFloat(headerStyle.borderRightWidth) || 0)
    const rightDiff = contentRight - actionsRect.right
    if (Math.abs(rightDiff) >= 0.5) dx = Math.round((dx + rightDiff) * 10) / 10
    // Vertical: the actions' text bottom lands on the tab text bottom.
    const tabBottom = textBottom(tabBtn)
    if (tabBottom !== null) {
      let maxBottom: number | null = null
      for (const sel of ['[class$="_label"]', '[class$="_count"]']) {
        const b = textBottom(actions.querySelector(sel))
        if (b !== null && (maxBottom === null || b > maxBottom)) maxBottom = b
      }
      if (maxBottom !== null) {
        const bottomDiff = tabBottom - maxBottom
        if (Math.abs(bottomDiff) >= 0.5) dy = Math.round((dy + bottomDiff) * 10) / 10
      }
    }
    const next = `translate(${dx}px, ${dy}px)`
    if (actions.style.transform !== next) actions.style.transform = next
    // Reserve the painted width on the row itself, so the tab labels never
    // slide under it. The value rides a CSS variable on <html>: React
    // recreates the row node on re-render, which would drop an inline
    // reservation until the next sync tick, and until then the labels render
    // underneath the painted actions.
    const reserve = `${Math.ceil(actionsRect.width) + 8}px`
    const rootStyle = document.documentElement.style
    if (rootStyle.getPropertyValue(HEADER_RESERVE_VAR) !== reserve) rootStyle.setProperty(HEADER_RESERVE_VAR, reserve)
  }

  function unseatHeaderActions(): void {
    document.body.classList.remove(HEADER_SEATED_CLASS)
    document.documentElement.style.removeProperty(HEADER_RESERVE_VAR)
    const header = document.querySelector('[class$="_header"]')
    const tabs = header !== null ? header.querySelector('[class$="_tabs"]') : null
    const actions = header !== null ? header.querySelector('[class$="_titleCluster"] [class$="_headerActions"]') : null
    if (actions instanceof HTMLElement) actions.style.transform = ''
    // The v67 padding reservation is gone with the v80 cap; clearing it keeps a
    // profile that hot-updated from an older build from keeping a stale inline
    // width on the row.
    if (tabs instanceof HTMLElement) tabs.style.paddingRight = ''
    if (headerObserver !== null) {
      headerObserver.disconnect()
      headerObserver = null
      observedHeader = null
    }
  }

  function ensureWhaleObserver(): void {
    if (whaleObserver !== null || typeof MutationObserver === 'undefined' || !document.body) return
    whaleObserver = new MutationObserver(() => { syncWhale() })
    whaleObserver.observe(document.body, { attributes: true, attributeFilter: ['data-sidebar-collapsed'], subtree: true })
  }

  /**
   * Observe the conversation header subtree and mark its geometry dirty on any
   * re-render (label text, badge count, node replacement). The per-tick
   * alignment then reads layout only when the header actually changed instead
   * of on every tick while a message streams. The observer is swapped when the
   * header node is replaced and disconnected with the layer.
   */
  function ensureHeaderObserver(header: Element | null): void {
    if (typeof MutationObserver === 'undefined') return
    if (observedHeader === header && headerObserver !== null) return
    headerObserver?.disconnect()
    headerObserver = null
    observedHeader = null
    if (header === null) return
    headerObserver = new MutationObserver(() => { headerGeometryDirty = true })
    headerObserver.observe(header, { childList: true, subtree: true, characterData: true, attributes: true, attributeFilter: ['class'] })
    observedHeader = header
    headerGeometryDirty = true
  }

  function evaluate(): void {
    // A viewport change invalidates every measured position.
    headerGeometryDirty = true
    if (!adaptEnabled) {
      revert()
      return
    }
    if (isMobilePortrait()) {
      apply()
      ensureWhaleObserver()
      // A viewport shrink (split-screen, foldable, rotation) can leave the
      // whale — the only portrait sidebar entry — parked beyond the new right
      // edge while it stays visible; re-clamp it here. Skipped mid-drag so a
      // resize cannot yank the button away from the finger.
      if (active && drag === null) applyWhalePos()
    } else {
      revert()
    }
  }
  evaluate()
  window.addEventListener('orientationchange', evaluate)
  window.addEventListener('resize', evaluate)
  // The 600ms tick is a page-lifetime wake source; pause it while the page
  // is hidden (backgrounded phone tab) and resume on return.
  document.addEventListener('visibilitychange', () => { setWhaleTimer(document.visibilityState !== 'hidden') })

  // v51: Enter only inserts a newline on mobile (send goes through the send
  // button). Captured at document level so the official Enter-to-send
  // handler never sees the event. The rewrite is scoped to the composer:
  // `_input` is also the class of the settings, plugin and agent-preset text
  // fields, where swallowing Enter and inserting a newline into a single-line
  // input left the key dead.
  function onKeydownCapture(e: KeyboardEvent): void {
    if (!active) return
    if (e.key !== 'Enter' || e.shiftKey || e.ctrlKey || e.metaKey || e.altKey) return
    const t = e.target
    if (!(t instanceof HTMLElement)) return
    if (composerFieldOf(t) === null) return
    // keyCode 229 is the classic IME-confirm signal (Safari fires
    // compositionend before the Enter keydown) — never treat it as a
    // plain newline.
    if (e.isComposing || e.keyCode === 229) return
    e.preventDefault()
    e.stopPropagation()
    try { document.execCommand('insertText', false, '\n') } catch {}
  }
  document.addEventListener('keydown', onKeydownCapture, true)

  function collapseSidebar(): void {
    toggleSidebarVerified()
  }

  // Auto-collapse the expanded sidebar on mobile: after clicking a session
  // row, or when tapping anywhere outside the sidebar (overlays/dialogs and
  // the whale excluded).
  function onClickCapture(e: MouseEvent): void {
    if (!active) return
    const frame = appFrame()
    if (frame === null || frame.hasAttribute('data-sidebar-collapsed')) return
    const t = e.target
    if (!(t instanceof Element)) return
    if (t.closest('[class*="_sidebarCol"]') !== null) {
      // v68: opening settings also folds the sidebar so the modal closes
      // back into a clean conversation view. Clicks on the session
      // row-actions ellipsis (or its opened menu anchor) must NOT collapse
      // the sidebar — they open the action menu. v76: clicking the top-level
      // New Session also folds. v77: clicking a workspace row's new-session
      // button also folds.
      const topNewSessionClicked = t.closest('[class$="_newSession"], [class$="_brand"]') !== null
      let projectNewSessionClicked = false
      const projectActions = t.closest('[class*="_projectRow"] [class*="_rowActions"]')
      if (projectActions !== null) {
        const btn = t.closest('button')
        const btns = projectActions.querySelectorAll('button')
        projectNewSessionClicked = btn !== null && btns.length > 0 && btn === btns[btns.length - 1]
      }
      let shouldCollapse = false
      if (t.closest('[class*="_sessionRow"]') !== null) {
        shouldCollapse = t.closest('[class*="_rowActions"]') === null
      } else if (t.closest('[class$="_settingsArea"]') !== null || topNewSessionClicked || projectNewSessionClicked) {
        shouldCollapse = true
      }
      if (shouldCollapse) collapseSidebar()
      return
    }
    if (t.closest('[class$="_overlay"], [class$="_dialog"], [class$="_menu"], [class*="_portal"], [id="dshRemoteWhale"], [id="dshLanGate"]') !== null) return
    collapseSidebar()
  }
  document.addEventListener('click', onClickCapture, true)

  // v65/v66: swipe gestures. Swiping LEFT while the sidebar is expanded
  // collapses it; swiping RIGHT in the conversation view opens it. Vertical
  // swipes (list scrolling), swipes starting on inputs, on the whale, or
  // inside horizontally scrollable containers are ignored.
  function insideHScrollable(el: Element): boolean {
    let n: Element | null = el
    while (n !== null && n !== document.body) {
      const cs = getComputedStyle(n)
      if ((cs.overflowX === 'auto' || cs.overflowX === 'scroll') && n.scrollWidth > n.clientWidth + 4) return true
      n = n.parentElement
    }
    return false
  }
  document.addEventListener('touchstart', (e) => {
    if (!active) return
    // Multi-finger touches are never a swipe: a pinch that happens to end with
    // >60px of horizontal finger travel would otherwise toggle the sidebar.
    if (e.touches.length > 1) {
      swipeTouch = null
      return
    }
    const t = e.target
    const editable = t instanceof HTMLElement && t.isContentEditable
    if (t instanceof Element && (t.tagName === 'TEXTAREA' || t.tagName === 'INPUT' || editable || t.closest(`#${WHALE_ID}`) !== null || t.closest('table, [class$="_table"], [class$="_tablePane"]') !== null)) {
      swipeTouch = null
      return
    }
    const ct = e.changedTouches[0]
    if (ct === undefined) return
    // The horizontally-scrollable veto is judged at release (see touchend):
    // evaluating it here forced a style recalc plus a synchronous layout on
    // every tap and scroll-start while the page was dirty, for a gesture that
    // mostly never becomes a swipe.
    swipeTouch = { x: ct.clientX, y: ct.clientY, id: ct.identifier, el: t instanceof Element ? t : null }
  }, { capture: true, passive: true })
  document.addEventListener('touchend', (e) => {
    if (swipeTouch === null) return
    // Still more than one finger down: a pinch is in progress, not a swipe.
    if (e.touches.length > 0) return
    const ct = e.changedTouches[0]
    if (ct === undefined || ct.identifier !== swipeTouch.id) return
    const dx = ct.clientX - swipeTouch.x
    const dy = ct.clientY - swipeTouch.y
    const start = swipeTouch
    swipeTouch = null
    if (!active) return
    if (Math.abs(dx) < 60 || Math.abs(dx) < Math.abs(dy) * 1.5) return
    // A gesture that started inside a horizontally scrollable container belongs
    // to that container, not to the sidebar. Judged now, only for a gesture
    // that already qualified as a swipe.
    if (start.el !== null && insideHScrollable(start.el)) return
    const frame = frameEl()
    if (frame === null) return
    if (nodeOf('[class$="_overlay"], [class$="_dialog"], [class$="_menu"], [class*="_portal"]') !== null) return
    const collapsed = frame.hasAttribute('data-sidebar-collapsed')
    if (dx < 0 && !collapsed) collapseSidebar()
    else if (dx > 0 && collapsed) toggleSidebarVerified()
  }, { capture: true, passive: true })
  document.addEventListener('touchcancel', () => {
    swipeTouch = null
  }, true)

  // Long-press a session row opens the same action menu as the desktop's
  // right-side ellipsis button (rename / fork / archive). On touch the
  // row-actions button is hover-only, so a long press reveals + clicks it.
  const LONG_PRESS_MS = 500
  const LONG_PRESS_MOVE = 10
  let longPress: { row: Element; x: number; y: number; timer: number | null; triggered: boolean } | null = null
  let suppressSessionClickUntil = 0
  let suppressSessionClickRow: Element | null = null
  let longPressMenuGuardUntil = 0

  function clearLongPress(): void {
    if (longPress !== null) {
      if (longPress.timer !== null) window.clearTimeout(longPress.timer)
      longPress = null
    }
  }

  function openSessionMenu(row: Element): void {
    const actions = row.querySelector('[class*="_rowActions"]')
    const btn = actions?.querySelector('button')
    if (actions === null || btn === null) return
    // The official row hides actions until hover/menuOpen; force the anchor
    // visible just long enough for .click() to be accepted.
    longPressMenuGuardUntil = Date.now() + 1200
    ;(actions as HTMLElement).style.display = 'inline-flex'
    try {
      (btn as HTMLElement).click()
    } finally {
      window.setTimeout(() => { (actions as HTMLElement).style.display = '' }, 50)
    }
  }
  document.addEventListener('touchstart', (e) => {
    if (!active) return
    const t = e.target
    if (!(t instanceof Element)) {
      clearLongPress()
      return
    }
    const row = t.closest('[class*="_sessionRow"]')
    if (row === null || t.closest('[class*="_rowActions"]') !== null) {
      clearLongPress()
      return
    }
    const ct = e.changedTouches[0]
    if (ct === undefined) return
    clearLongPress()
    const lp = { row, x: ct.clientX, y: ct.clientY, timer: null as number | null, triggered: false }
    lp.timer = window.setTimeout(() => {
      if (longPress !== lp) return
      lp.triggered = true
      openSessionMenu(lp.row)
      try { navigator.vibrate?.(10) } catch {}
    }, LONG_PRESS_MS)
    longPress = lp
  }, { capture: true, passive: true })
  document.addEventListener('touchmove', (e) => {
    if (!active || longPress === null) return
    const ct = e.changedTouches[0]
    if (ct === undefined) return
    if (Math.abs(ct.clientX - longPress.x) > LONG_PRESS_MOVE || Math.abs(ct.clientY - longPress.y) > LONG_PRESS_MOVE) {
      clearLongPress()
    }
  }, { capture: true, passive: true })
  document.addEventListener('touchend', (e) => {
    if (!active || longPress === null) return
    const ct = e.changedTouches[0]
    if (ct === undefined) return
    const lp = longPress
    clearLongPress()
    if (lp.triggered) {
      // Stop the finger-lift from also opening the session; the menu is
      // already open and the sidebar should stay put.
      e.preventDefault()
      suppressSessionClickUntil = Date.now() + 800
      suppressSessionClickRow = lp.row
    }
  }, { capture: true, passive: false })
  document.addEventListener('touchcancel', () => {
    clearLongPress()
  }, true)
  // A long press ends with a synthetic click; swallow that one click so it
  // neither opens the conversation nor collapses the sidebar.
  window.addEventListener('click', (e) => {
    if (!active || Date.now() > suppressSessionClickUntil) return
    const t = e.target
    if (t instanceof Element && suppressSessionClickRow !== null && (t === suppressSessionClickRow || suppressSessionClickRow.contains(t))) {
      e.stopPropagation()
      e.preventDefault()
      suppressSessionClickUntil = 0
      suppressSessionClickRow = null
    }
  }, true)
  // Some Android browsers fire a native context menu after a long press.
  document.addEventListener('contextmenu', (e) => {
    if (!active) return
    const t = e.target
    if (!(t instanceof Element)) return
    if (t.closest('[class*="_sessionRow"]') !== null && ((longPress !== null && longPress.triggered) || Date.now() <= suppressSessionClickUntil)) {
      e.preventDefault()
    }
  }, true)
  // Keep the long-press menu open across the finger-lift: the official
  // Menu closes on pointerleave of its root, which fires on touch end.
  document.addEventListener('pointerleave', (e) => {
    if (!active || Date.now() > longPressMenuGuardUntil) return
    const t = e.target
    if (t instanceof Element && (t.closest('[class*="_rowActions"]') !== null || t.closest('[class*="_sessionRow"]') !== null || t.closest('[class*="_projectRow"]') !== null)) {
      e.stopPropagation()
    }
  }, true)

  // Intercept programmatic .focus() on the composer field: the official
  // conversation component focuses it on mount and on session changes; user
  // taps focus it through the browser's own pipeline. Only allow composer
  // focus that follows a real tap on the field itself. The composer field is
  // the official contenteditable input root (`data-composer-input`) on this
  // cohort — matching only textarea/input missed it entirely, so every session
  // open popped the phone keyboard. The queue-row editor input is deliberately
  // NOT a composer field: its autoFocus must keep working.
  const isComposerField = (el: Element | null): el is HTMLElement => {
    if (!(el instanceof HTMLElement)) return false
    if (el.closest(COMPOSER_SELECTOR) === null) return false
    if (el.matches('[data-composer-input]')) return true
    if (el.tagName === 'TEXTAREA') return true
    return el.tagName === 'INPUT' && el.matches('[class*="_input"]')
  }
  /** The composer field that owns an event target, if any. */
  const composerFieldOf = (target: EventTarget | null): HTMLElement | null => {
    const el = target instanceof Element ? target.closest('[data-composer-input], [class*="_input"], textarea') : null
    return isComposerField(el) ? el : null
  }
  const lanOrigFocus = HTMLElement.prototype.focus
  const patchedFocus = function (this: HTMLElement, options?: FocusOptions): void {
    if (active && isComposerField(this) && Date.now() - lastComposerTap >= 800) return
    lanOrigFocus.call(this, options)
  }
  /** (Re-)install the composer-focus guard (see setEnabled). */
  const installFocusPatch = (): void => {
    HTMLElement.prototype.focus = patchedFocus
  }
  /**
   * Remove the guard when the layer is disabled. A patch another plugin
   * installed after ours is left alone (identity check), so disabling this
   * layer never removes someone else's behavior.
   */
  const restoreFocusPatch = (): void => {
    if (HTMLElement.prototype.focus === patchedFocus) HTMLElement.prototype.focus = lanOrigFocus
  }
  installFocusPatch()
  document.addEventListener('pointerdown', (e) => {
    if (!active) return
    if (composerFieldOf(e.target) !== null) lastComposerTap = Date.now()
  }, true)

  // The plugin apply() wires toggleSidebar/closeDetails to ctx.layout once
  // it is live, and flips the master switch when the settings snapshot
  // settles.
  w.__dshRemoteAdapt = {
    evaluate,
    toggleSidebar: null,
    closeDetails: null,
    translate: null,
    setEnabled(on: boolean): void {
      adaptEnabled = on
      if (on) {
        installFocusPatch()
        evaluate()
      } else {
        revert()
        restoreFocusPatch()
      }
    },
    flushCloseDetails(): void {
      // The first apply() ran before any wiring existed, so its
      // closeDetails call was a no-op; replay it once the layout face is
      // live so a restored details panel cannot sit hidden-uncloseable.
      if (active) w.__dshRemoteAdapt?.closeDetails?.()
    },
  }
}
